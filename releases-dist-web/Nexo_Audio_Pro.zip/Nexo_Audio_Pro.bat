@echo off
chcp 1252 >nul
setlocal enabledelayedexpansion
title EL NEXO v5.0 - AUDIO PRO [PLAN: FREE]
color 0B

:: AUTO-ELEVACION
fsutil dirty query %systemdrive% >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs -WorkingDirectory '%~dp0'"
    exit /b
)
cd /d "%~dp0"

cls
color 0B
echo.
echo  ============================================================
echo    ______ _       _   _ _______   ______  
echo   ^|  ____^|^| ^|     ^| \ ^| ^|^|  ___\ \ / / __ \ 
echo   ^| ^|__  ^| ^|     ^|  \^| ^|^| ^|__  \ V / ^|  ^| ^|
echo   ^|  __^| ^| ^|     ^| . ` ^|^|  __^|  ^> ^<^| ^|  ^| ^|
echo   ^| ^|____^| ^|____ ^| ^|\  ^|^| ^|____/ . \ ^|__^| ^|
echo   ^|______^|^|______^|^|_^| \_^|^|______/_/\_\____/  
echo.
echo  ============================================================
echo   AUDIO PRO   ^|   PLAN: FREE
echo   Para la version completa: elnexocenter.com/optimizer
echo  ============================================================
echo.

echo  [PASO 1/2] Elevando prioridad del scheduler de audio...
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio" /v "Scheduling Category" /t REG_SZ /d "High" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio" /v "SFIO Priority" /t REG_SZ /d "High" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio" /v "GPU Priority" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio" /v "Priority" /t REG_DWORD /d 2 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio" /v "Latency Sensitive" /t REG_SZ /d "True" /f >nul 2>&1
echo  [OK] Prioridad de audio maximizada en el scheduler.

echo.
echo  [PASO 2/2] Eliminando throttling de red para audio...
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NetworkThrottlingIndex" /t REG_DWORD /d 4294967295 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /t REG_DWORD /d 0 /f >nul 2>&1
echo  [OK] Throttling de red eliminado.

echo.
echo  ============================================================
echo   AUDIO PRO FREE - COMPLETADO
echo  ============================================================
echo.
echo   Cambios aplicados en esta version FREE:
echo   [OK] Scheduling Category High para audio
echo   [OK] Latency Sensitive activado
echo   [OK] Throttling de red para audio eliminado
echo.
echo  ============================================================
echo   BLOQUEADO EN PLAN FREE - DISPONIBLE EN NEXO OPTIMIZER PRO:
echo  ============================================================
echo.
echo   [PRO] Purga de Nahimic (MSI, Samsung, ASUS)
echo         Causa principal del crackling y latencia DPC alta
echo         La version FREE NO lo elimina
echo.
echo   [PRO] Purga de Sonic Studio / Sonic Suite (ASUS ROG/TUF)
echo         Otro causante conocido de audio con cortes
echo.
echo   [PRO] Eliminacion de Realtek Audio Console UWP
echo         La app oculta que genera interrupciones innecesarias
echo.
echo   [PRO] MSI Mode en controladores HD Audio
echo         Elimina la latencia DPC a nivel de hardware
echo         Sin esto los picos de latencia siguen presentes
echo.
echo   Consigue todo esto y mucho mas en:
echo   elnexocenter.com/optimizer
echo  ============================================================
echo.
set /p "reboot=Deseas reiniciar? (S/N): "
if /i "%reboot%"=="S" shutdown /r /t 10 /c "Reiniciando Audio Pro FREE El Nexo..."
exit
