@echo off
chcp 1252 >nul
setlocal enabledelayedexpansion
title EL NEXO v5.0 - PROCESS KILLER [PLAN: FREE]
color 0B

fsutil dirty query %systemdrive% >nul 2>&1
if %errorlevel% neq 0 (
    cls & color 0C
    echo.
    echo  ============================================================
    echo   ACCESO DENEGADO - Se requieren permisos de Administrador
    echo  ============================================================
    echo   Haz clic derecho y selecciona "Ejecutar como administrador"
    echo  ============================================================
    pause & exit /b
)

cls
color 0B
echo.
echo  ============================================================
echo    ______ _       _   _ _______   ______  
echo   ^|  ____^|^| ^|     ^| \ ^| ^|^|  ___\ \ / / __ \ 
echo   ^| ^|__  ^| ^|     ^|  \^| ^|^| ^|__  \ V / ^|  ^| ^|
echo   ^|  __^| ^| ^|     ^| . ` ^|^|  __^|  ^> ^<^| ^|  ^| ^|
echo   ^| ^|____^| ^|____ ^| ^|\  ^|^| ^|____/ . \ ^|__^| ^|
echo   ^|______^|^|______^|^|_^| \_^|^|______/_/\_\____/  
echo.
echo  ============================================================
echo   PROCESS KILLER   ^|   PLAN: FREE
echo   Version FREE: solo Nivel 1 disponible
echo   Para la version completa: elnexocenter.com/optimizer
echo  ============================================================
echo.

set /p "backup=Crear punto de restauracion? (S/N): "
if /i "%backup%"=="S" (
    powershell -Command "Checkpoint-Computer -Description 'El Nexo Process Killer FREE' -RestorePointType 'MODIFY_SETTINGS'" 2>nul
    if !errorlevel! equ 0 (echo  [OK] Punto creado.) else (echo  [!] No se pudo crear.)
) else (echo  [!] Saltando respaldo.)
echo.

:: ANALISIS RAPIDO
echo  [ANALISIS] Escaneando procesos activos...
for /f "tokens=*" %%r in ('powershell -NoProfile -Command "try { $l=0; $launchers=@('steam','epicgameslauncher','origin','discord','battlenet','upc','eadesktop'); Get-Process | ForEach-Object { $n=$_.ProcessName.ToLower(); if ($launchers -contains $n){$l+=[math]::Round($_.WorkingSet64/1MB)} }; Write-Output \"L=$l\" } catch { Write-Output 'L=0' }"') do set "RESULT=%%r"
set "L_VAL=%RESULT:L=%"
if not defined L_VAL set "L_VAL=0"

echo.
echo  ============================================================
echo   Procesos detectados
echo   RAM estimada a liberar: ~%L_VAL% MB
echo  ============================================================
echo.
echo  [FREE] Solo disponible: NIVEL 1 - Limpieza de launchers
echo.
echo  [BLOQUEADO] Nivel 2 - Purga de updaters y servicios permanentes
echo  [BLOQUEADO] Nivel 3 - Modo Zero-Point con kill de RGB software
echo.
echo  Continuar con Nivel 1? (unica opcion en version FREE)
set /p "confirm=Ejecutar Nivel 1? (S/N): "
if /i not "%confirm%"=="S" (echo  Cancelado. & pause & exit)
echo.

:: NIVEL 1 - LIMPIEZA SUPERFICIAL
echo  [EJECUTANDO] Nivel 1 - Limpieza Superficial...
echo.
powershell -NoProfile -Command ^
    "function Kill-Tree($id) { Get-CimInstance Win32_Process | Where-Object {$_.ParentProcessId -eq $id} | ForEach-Object { Kill-Tree $_.ProcessId }; try { Stop-Process -Id $id -Force -EA Stop } catch {} }; " ^
    "$killed=0; " ^
    "$launchers=@('steam','epicgameslauncher','origin','eadesktop','upc','battlenet'); " ^
    "foreach ($l in $launchers) { Get-Process -Name $l -EA SilentlyContinue | Where-Object {$_.MainWindowHandle -eq 0} | ForEach-Object { Kill-Tree $_.Id; $killed++; Write-Host '  [OK] Cerrado:' $_.ProcessName -ForegroundColor Green } }; " ^
    "$bloat=@('widget','gamebar'); " ^
    "foreach ($b in $bloat) { Get-Process -Name $b -EA SilentlyContinue | Where-Object {$_.MainWindowHandle -eq 0} | ForEach-Object { Kill-Tree $_.Id; $killed++ } }; " ^
    "[GC]::Collect(); " ^
    "Write-Host ('{0} procesos cerrados.' -f $killed) -ForegroundColor Yellow"

echo.
echo  ============================================================
echo   PROCESS KILLER FREE - COMPLETADO
echo  ============================================================
echo.
echo   Cambios aplicados en esta version FREE:
echo   [OK] Nivel 1: Launchers inactivos cerrados
echo   [OK] Widgets y GameBar cerrados
echo   [OK] RAM liberada
echo.
echo  ============================================================
echo   BLOQUEADO EN PLAN FREE - DISPONIBLE EN NEXO OPTIMIZER PRO:
echo  ============================================================
echo.
echo   [PRO] Nivel 2 - Purga Tactica
echo         Desactiva updaters de Google/Edge/Adobe PERMANENTEMENTE
echo         Desactiva DiagTrack y telemetria de fondo para siempre
echo.
echo   [PRO] Nivel 3 - Modo Zero-Point
echo         Mata TODO excepto procesos del kernel
echo         Kill de software RGB (Armoury Crate, iCUE, RGB Fusion)
echo         Evita falsos positivos en BattlEye, Vanguard y EAC
echo.
echo   Consigue todo esto y mucho mas en:
echo   elnexocenter.com/optimizer
echo  ============================================================
echo.
set /p "reboot=Deseas reiniciar? (S/N): "
if /i "%reboot%"=="S" shutdown /r /t 10 /c "Reiniciando Process Killer FREE El Nexo..."
exit
