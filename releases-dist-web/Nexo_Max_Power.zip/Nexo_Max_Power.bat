@echo off
chcp 1252 >nul
setlocal enabledelayedexpansion
title EL NEXO v5.0 - MAX POWER [PLAN: FREE]
color 0B

fsutil dirty query %systemdrive% >nul 2>&1
if %errorlevel% neq 0 (
    cls & color 0C
    echo.
    echo  ============================================================
    echo   ACCESO DENEGADO - Se requieren permisos de Administrador
    echo  ============================================================
    echo.
    echo   Haz clic derecho y selecciona "Ejecutar como administrador"
    echo  ============================================================
    pause & exit /b
)

cls
color 0B
echo.
echo  ============================================================
echo    ______ _       _   _ _______   ______  
echo   ^|  ____^|^| ^|     ^| \ ^| ^|^|  ___\ \ / / __ \ 
echo   ^| ^|__  ^| ^|     ^|  \^| ^|^| ^|__  \ V / ^|  ^| ^|
echo   ^|  __^| ^| ^|     ^| . ` ^|^|  __^|  ^> ^<^| ^|  ^| ^|
echo   ^| ^|____^| ^|____ ^| ^|\  ^|^| ^|____/ . \ ^|__^| ^|
echo   ^|______^|^|______^|^|_^| \_^|^|______/_/\_\____/  
echo.
echo  ============================================================
echo   MAX POWER   ^|   PLAN: FREE
echo   Para la version completa: elnexocenter.com/optimizer
echo  ============================================================
echo.

:: DETECCION PC / LAPTOP
echo  [DETECCION] Identificando tipo de dispositivo...
echo.
set "DEVICE_TYPE=PC"
set "DEVICE_NAME=PC de Escritorio"
for /f "skip=1 tokens=*" %%b in ('wmic path win32_battery get BatteryStatus 2^>nul') do (
    set "BAT_LINE=%%b"
    if not "!BAT_LINE!"=="" if not "!BAT_LINE!"=="  " (
        set "DEVICE_TYPE=LAPTOP"
        set "DEVICE_NAME=Portatil / Laptop"
    )
)
echo  [INFO] Dispositivo: %DEVICE_NAME%
echo.

:: PUNTO DE RESTAURACION
echo  [PASO 1] Creando punto de restauracion...
set /p "backup=Crear respaldo antes de continuar? (S/N): "
if /i "%backup%"=="S" (
    powershell -Command "Checkpoint-Computer -Description 'El Nexo Max Power FREE' -RestorePointType 'MODIFY_SETTINGS'" 2>nul
    if !errorlevel! equ 0 (echo  [OK] Punto creado.) else (echo  [!] No se pudo crear.)
) else (echo  [!] Saltando respaldo.)

:: PLAN DE ENERGIA
echo.
echo  [PASO 2] Creando plan de energia personalizado...
if "%DEVICE_TYPE%"=="PC" (
    set "NEXO_GUID=11111111-1111-1111-1111-111111111111"
    set "PLAN_NOMBRE=Maximo Rendimiento El Nexo"
) else (
    set "NEXO_GUID=22222222-2222-2222-2222-222222222222"
    set "PLAN_NOMBRE=Alto Rendimiento El Nexo"
)
powercfg -delete %NEXO_GUID% >nul 2>&1
powercfg -duplicatescheme 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c %NEXO_GUID% >nul 2>&1
powercfg -changename %NEXO_GUID% "%PLAN_NOMBRE%" "Plan El Nexo FREE" >nul 2>&1
powercfg -setactive %NEXO_GUID%
powercfg -change -monitor-timeout-ac 0 >nul 2>&1
powercfg -change -disk-timeout-ac 0 >nul 2>&1
powercfg -change -standby-timeout-ac 0 >nul 2>&1
powercfg -setacvalueindex %NEXO_GUID% sub_processor PROCTHROTTLEMIN 100 >nul 2>&1
powercfg -setacvalueindex %NEXO_GUID% sub_processor PROCTHROTTLEMAX 100 >nul 2>&1
powercfg -setacvalueindex %NEXO_GUID% sub_processor PERFBOOSTMODE 2 >nul 2>&1
powercfg -setacvalueindex %NEXO_GUID% sub_pciexpress aspm 0 >nul 2>&1
powercfg -setacvalueindex %NEXO_GUID% sub_usb usbsuspend 0 >nul 2>&1
if "%DEVICE_TYPE%"=="PC" powercfg -h off >nul 2>&1
echo  [OK] Plan "%PLAN_NOMBRE%" activado.

:: SERVICIOS DE TELEMETRIA
echo.
echo  [PASO 3] Desactivando servicios de telemetria...
for %%s in (DiagTrack dmwappushservice WerSvc PcaSvc DPS RetailDemo) do (
    sc stop %%s >nul 2>&1
    sc config %%s start=disabled >nul 2>&1
)
echo  [OK] Telemetria desactivada.

:: PRIORIDAD DE JUEGOS (basica)
echo.
echo  [PASO 4] Configurando prioridad basica de juegos...
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Priority" /t REG_DWORD /d 6 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Scheduling Category" /t REG_SZ /d "High" /f >nul 2>&1
echo  [OK] Prioridad de juegos configurada.

echo.
echo  ============================================================
echo   MAX POWER FREE - COMPLETADO
echo  ============================================================
echo.
echo   Cambios aplicados en esta version FREE:
echo   [OK] Plan de energia personalizado
echo   [OK] CPU al 100%% sin throttling
echo   [OK] Telemetria de Microsoft desactivada
echo   [OK] Prioridad basica de juegos
echo.
echo  ============================================================
echo   BLOQUEADO EN PLAN FREE - DISPONIBLE EN NEXO OPTIMIZER PRO:
echo  ============================================================
echo.
echo   [PRO] MSI Mode en GPU, NIC y almacenamiento
echo         (Elimina latencia DPC - impacto directo en FPS)
echo.
echo   [PRO] Optimizacion del kernel (bcdedit TSCSync, x2APIC)
echo         (Reduce micro-stutters a nivel de sistema)
echo.
echo   [PRO] GPU: ULPS off + MPO off
echo         (Elimina pantallazos negros en Alt+Tab)
echo.
echo   [PRO] Win32PrioritySeparation + DisablePagingExecutive
echo         (Prioridad absoluta de CPU para juegos)
echo.
echo   [PRO] GPU Priority 8 en scheduler multimedia
echo         (El ajuste mas impactante para 1%% lows)
echo.
echo   Consigue todo esto y mucho mas en:
echo   elnexocenter.com/optimizer
echo  ============================================================
echo.
start powercfg.cpl
set /p "reboot=Deseas reiniciar ahora? (S/N): "
if /i "%reboot%"=="S" shutdown /r /t 10 /c "Reiniciando Max Power FREE El Nexo..."
exit
