@echo off
chcp 1252 >nul
setlocal enabledelayedexpansion
title EL NEXO v5.0 - NET OPTIMIZER [PLAN: FREE]
color 0B

fsutil dirty query %systemdrive% >nul 2>&1
if %errorlevel% neq 0 (
    cls & color 0C
    echo.
    echo  ============================================================
    echo   ACCESO DENEGADO - Se requieren permisos de Administrador
    echo  ============================================================
    echo   Haz clic derecho y selecciona "Ejecutar como administrador"
    echo  ============================================================
    pause & exit /b
)

cls
color 0B
echo.
echo  ============================================================
echo    ______ _       _   _ _______   ______  
echo   ^|  ____^|^| ^|     ^| \ ^| ^|^|  ___\ \ / / __ \ 
echo   ^| ^|__  ^| ^|     ^|  \^| ^|^| ^|__  \ V / ^|  ^| ^|
echo   ^|  __^| ^| ^|     ^| . ` ^|^|  __^|  ^> ^<^| ^|  ^| ^|
echo   ^| ^|____^| ^|____ ^| ^|\  ^|^| ^|____/ . \ ^|__^| ^|
echo   ^|______^|^|______^|^|_^| \_^|^|______/_/\_\____/  
echo.
echo  ============================================================
echo   NET OPTIMIZER   ^|   PLAN: FREE
echo   Para la version completa: elnexocenter.com/optimizer
echo  ============================================================
echo.

set /p "backup=Crear punto de restauracion? (S/N): "
if /i "%backup%"=="S" (
    powershell -Command "Checkpoint-Computer -Description 'El Nexo Net Optimizer FREE' -RestorePointType 'MODIFY_SETTINGS'" 2>nul
    if !errorlevel! equ 0 (echo  [OK] Punto creado.) else (echo  [!] No se pudo crear.)
) else (echo  [!] Saltando respaldo.)
echo.

echo  [PASO 1/4] Optimizando pila TCP/IP basica...
netsh int tcp set global autotuninglevel=normal >nul 2>&1
netsh int tcp set global rss=enabled >nul 2>&1
netsh int tcp set global timestamps=disabled >nul 2>&1
echo  [OK] TCP/IP optimizado.

echo.
echo  [PASO 2/4] QoS al 0%% (ancho de banda completo)...
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Psched" /v "NonBestEffortLimit" /t REG_DWORD /d 0 /f >nul 2>&1
echo  [OK] Reserva de ancho de banda eliminada.

echo.
echo  [PASO 3/4] Configuracion de DNS...
echo.
echo  Opciones de DNS:
echo   [1] Cloudflare 1.1.1.1
echo   [2] Google    8.8.8.8
echo   [3] Mantener DNS actual
echo.
set /p "dns_opt=Elige una opcion (1/2/3): "
if "%dns_opt%"=="1" (
    netsh interface ip set dns "Ethernet" static 1.1.1.1 primary >nul 2>&1
    netsh interface ip add dns "Ethernet" 1.0.0.1 index=2 >nul 2>&1
    netsh interface ip set dns "Wi-Fi" static 1.1.1.1 primary >nul 2>&1
    netsh interface ip add dns "Wi-Fi" 1.0.0.1 index=2 >nul 2>&1
    echo  [OK] DNS Cloudflare configurado.
) else if "%dns_opt%"=="2" (
    netsh interface ip set dns "Ethernet" static 8.8.8.8 primary >nul 2>&1
    netsh interface ip add dns "Ethernet" 8.8.4.4 index=2 >nul 2>&1
    netsh interface ip set dns "Wi-Fi" static 8.8.8.8 primary >nul 2>&1
    netsh interface ip add dns "Wi-Fi" 8.8.4.4 index=2 >nul 2>&1
    echo  [OK] DNS Google configurado.
) else (echo  [!] DNS sin cambios.)

echo.
echo  [PASO 4/4] Limpiando stack de red y cache DNS...
ipconfig /flushdns >nul 2>&1
netsh winsock reset catalog >nul 2>&1
echo  [OK] Stack de red limpiado.

echo.
echo  ============================================================
echo   NET OPTIMIZER FREE - COMPLETADO
echo  ============================================================
echo.
echo   Cambios aplicados en esta version FREE:
echo   [OK] TCP/IP basico optimizado
echo   [OK] QoS al 0%% (ancho de banda completo)
echo   [OK] DNS configurable (Cloudflare / Google)
echo   [OK] Winsock reset y cache DNS limpiada
echo.
echo  ============================================================
echo   BLOQUEADO EN PLAN FREE - DISPONIBLE EN NEXO OPTIMIZER PRO:
echo  ============================================================
echo.
echo   [PRO] Algoritmo de Nagle desactivado (TcpAckFrequency)
echo         (Paquetes enviados instantaneamente, sin batching)
echo.
echo   [PRO] CTCP como proveedor de congestion
echo         (Mejor algoritmo para gaming online competitivo)
echo.
echo   [PRO] Energy-Efficient Ethernet Realtek desactivado
echo         (Elimina picos de latencia incluso sin carga de red)
echo.
echo   [PRO] NetworkThrottlingIndex eliminado
echo         (Windows deja de limitar el trafico de red en juegos)
echo.
echo   Consigue todo esto y mucho mas en:
echo   elnexocenter.com/optimizer
echo  ============================================================
echo.
set /p "reboot=Deseas reiniciar ahora? (S/N): "
if /i "%reboot%"=="S" shutdown /r /t 10 /c "Reiniciando Net Optimizer FREE El Nexo..."
exit
