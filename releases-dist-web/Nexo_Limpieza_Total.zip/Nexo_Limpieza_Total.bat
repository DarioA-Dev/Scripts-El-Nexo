@echo off
chcp 1252 >nul
setlocal enabledelayedexpansion
title EL NEXO v5.0 - LIMPIEZA TOTAL [PLAN: FREE]
color 0B

fsutil dirty query %systemdrive% >nul 2>&1
if %errorlevel% neq 0 (
    cls & color 0C
    echo.
    echo  ============================================================
    echo   ACCESO DENEGADO - Se requieren permisos de Administrador
    echo  ============================================================
    echo   Haz clic derecho y selecciona "Ejecutar como administrador"
    echo  ============================================================
    pause & exit /b
)

cls
color 0B
echo.
echo  ============================================================
echo    ______ _       _   _ _______   ______  
echo   ^|  ____^|^| ^|     ^| \ ^| ^|^|  ___\ \ / / __ \ 
echo   ^| ^|__  ^| ^|     ^|  \^| ^|^| ^|__  \ V / ^|  ^| ^|
echo   ^|  __^| ^| ^|     ^| . ` ^|^|  __^|  ^> ^<^| ^|  ^| ^|
echo   ^| ^|____^| ^|____ ^| ^|\  ^|^| ^|____/ . \ ^|__^| ^|
echo   ^|______^|^|______^|^|_^| \_^|^|______/_/\_\____/  
echo.
echo  ============================================================
echo   LIMPIEZA TOTAL   ^|   PLAN: FREE
echo   Para la version completa: elnexocenter.com/optimizer
echo  ============================================================
echo.

set /p "backup=Crear punto de restauracion? (S/N): "
if /i "%backup%"=="S" (
    powershell -Command "Checkpoint-Computer -Description 'El Nexo Limpieza FREE' -RestorePointType 'MODIFY_SETTINGS'" 2>nul
    if !errorlevel! equ 0 (echo  [OK] Punto creado.) else (echo  [!] No se pudo crear.)
) else (echo  [!] Saltando respaldo.)
echo.

echo  [PASO 1/5] Limpiando cache de Windows Update...
net stop wuauserv >nul 2>&1
net stop bits >nul 2>&1
timeout /t 2 /nobreak >nul
if exist "%windir%\SoftwareDistribution\Download" (
    del /s /f /q "%windir%\SoftwareDistribution\Download\*.*" >nul 2>&1
    for /d %%D in ("%windir%\SoftwareDistribution\Download\*") do rd /s /q "%%D" >nul 2>&1
)
net start wuauserv >nul 2>&1
net start bits >nul 2>&1
echo  [OK] Cache de Windows Update eliminada.

echo.
echo  [PASO 2/5] Eliminando archivos temporales...
del /s /f /q "%temp%\*.*" >nul 2>&1
for /d %%D in ("%temp%\*") do rd /s /q "%%D" >nul 2>&1
del /s /f /q "%windir%\Temp\*.*" >nul 2>&1
for /d %%D in ("%windir%\Temp\*") do rd /s /q "%%D" >nul 2>&1
if exist "%windir%\Prefetch" del /s /f /q "%windir%\Prefetch\*.*" >nul 2>&1
echo  [OK] Temporales eliminados.

echo.
echo  [PASO 3/5] Limpiando historial de archivos recientes...
del /f /q "%AppData%\Microsoft\Windows\Recent\*.*" >nul 2>&1
del /f /q "%AppData%\Microsoft\Windows\Recent\AutomaticDestinations\*.*" >nul 2>&1
echo  [OK] Historial limpiado.

echo.
echo  [PASO 4/5] Limpiando logs de eventos...
for /f "tokens=*" %%e in ('wevtutil el 2^>nul') do wevtutil cl "%%e" >nul 2>&1
echo  [OK] Logs de eventos eliminados.

echo.
echo  [PASO 5/5] Reconstruyendo cache del Explorador...
taskkill /f /im explorer.exe >nul 2>&1
timeout /t 2 /nobreak >nul
del /f /q "%LocalAppData%\IconCache.db" >nul 2>&1
del /f /q "%LocalAppData%\Microsoft\Windows\Explorer\thumbcache_*.db" >nul 2>&1
rd /s /q %systemdrive%\$Recycle.bin >nul 2>&1
start explorer.exe
echo  [OK] Explorador reconstruido y papelera vaciada.

echo.
echo  ============================================================
echo   LIMPIEZA FREE - COMPLETADO
echo  ============================================================
echo.
echo   Cambios aplicados en esta version FREE:
echo   [OK] Cache de Windows Update eliminada
echo   [OK] Archivos temporales borrados
echo   [OK] Historial de archivos recientes limpiado
echo   [OK] Logs de eventos vaciados
echo   [OK] Cache del Explorador reconstruida
echo.
echo  ============================================================
echo   BLOQUEADO EN PLAN FREE - DISPONIBLE EN NEXO OPTIMIZER PRO:
echo  ============================================================
echo.
echo   [PRO] DISM /cleanup-image /resetbase
echo         (Elimina hasta 10 GB del almacen WinSxS)
echo.
echo   [PRO] Limpieza de shader cache GPU (NVIDIA y AMD)
echo         (GLCache, DXCache, D3DSCache)
echo.
echo   [PRO] Flush de Standby List de RAM
echo         (Libera RAM atascada que Windows no devuelve)
echo.
echo   Consigue todo esto y mucho mas en:
echo   elnexocenter.com/optimizer
echo  ============================================================
echo.
pause
exit
