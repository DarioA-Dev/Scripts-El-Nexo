@echo off
:: =========================================================================
::   EL NEXO - REVERSION DE OPTIMIZACIONES v4.0
::   Modulo: Restaurar Menu de Windows 11
:: =========================================================================
chcp 65001 >nul
setlocal enabledelayedexpansion
title EL NEXO v4.0 - REVERTIR MENU CLASICO
color 0B

:: AUTO-ELEVACION
fsutil dirty query %systemdrive% >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs -WorkingDirectory '%~dp0'"
    exit /b
)
cd /d "%~dp0"

:: CABECERA CIBERPUNK "EL NEXO"
cls
color 0B
echo.
echo  ============================================================
echo    ______ _       _   _ _______   ______  
echo   ^|  ____^|^| ^|     ^| \ ^| ^|^|  ___\ \ / / __ \ 
echo   ^| ^|__  ^| ^|     ^|  \^| ^|^| ^|__  \ V / ^|  ^| ^|
echo   ^|  __^| ^| ^|     ^| . ` ^|^|  __^|  ^> ^<^| ^|  ^| ^|
echo   ^| ^|____^| ^|____ ^| ^|\  ^|^| ^|____/ . \ ^|__^| ^|
echo   ^|______^|^|______^|^|_^| \_^|^|______/_/\_\____/  
echo.
echo  ============================================================
echo   PROTOCOLO: RESTAURAR MENU WINDOWS 11
echo   VERSION: 4.0 - Estado: Aplicando cambios...
echo  ============================================================
echo.

:: RESTORE MENU
echo  [PASO 1/2] Eliminando modificacion del registro...
echo.
reg delete "HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}" /f >nul 2>&1
echo  [OK] Clave de registro eliminada.

:: RESTART EXPLORER
echo.
echo  [PASO 2/2] Reiniciando Explorador de Windows...
echo.
taskkill /f /im explorer.exe >nul 2>&1
timeout /t 1 /nobreak >nul
start explorer.exe
echo  [OK] Menu de Windows 11 restaurado.

:: FINALIZACION
echo.
echo  ============================================================
echo   REVERSION COMPLETADA CON EXITO
echo  ============================================================
echo.
echo   El menu contextual de Windows 11 ha sido restaurado.
echo   Prueba a hacer clic derecho en cualquier parte.
echo.
echo  ============================================================
echo.
set /p "reboot= Deseas reiniciar el sistema ahora? (S/N): "
if /i "%reboot%"=="S" shutdown /r /t 10 /c "Reiniciando para completar la reversion..."

exit
