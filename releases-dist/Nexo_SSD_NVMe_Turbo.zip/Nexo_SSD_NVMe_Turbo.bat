@echo off
chcp 1252 >nul
setlocal enabledelayedexpansion
title EL NEXO v5.0 - SSD NVMe TURBO [PLAN: FREE]
color 0B

fsutil dirty query %systemdrive% >nul 2>&1
if %errorlevel% neq 0 (
    cls & color 0C
    echo.
    echo  ============================================================
    echo   ACCESO DENEGADO - Se requieren permisos de Administrador
    echo  ============================================================
    echo   Haz clic derecho y selecciona "Ejecutar como administrador"
    echo  ============================================================
    pause & exit /b
)

cls
color 0B
echo.
echo  ============================================================
echo    ______ _       _   _ _______   ______  
echo   ^|  ____^|^| ^|     ^| \ ^| ^|^|  ___\ \ / / __ \ 
echo   ^| ^|__  ^| ^|     ^|  \^| ^|^| ^|__  \ V / ^|  ^| ^|
echo   ^|  __^| ^| ^|     ^| . ` ^|^|  __^|  ^> ^<^| ^|  ^| ^|
echo   ^| ^|____^| ^|____ ^| ^|\  ^|^| ^|____/ . \ ^|__^| ^|
echo   ^|______^|^|______^|^|_^| \_^|^|______/_/\_\____/  
echo.
echo  ============================================================
echo   SSD NVMe TURBO   ^|   PLAN: FREE
echo   Para la version completa: elnexocenter.com/optimizer
echo  ============================================================
echo.

echo  [PASO 1] Creando punto de restauracion...
powershell -Command "Checkpoint-Computer -Description 'El Nexo SSD Turbo FREE' -RestorePointType 'MODIFY_SETTINGS'" 2>nul
echo  [OK] Punto creado.

echo.
echo  [PASO 2] Activando TRIM...
fsutil behavior set DisableDeleteNotify 0 >nul 2>&1
echo  [OK] TRIM activado.

echo.
echo  [PASO 3] Desactivando escrituras innecesarias...
fsutil behavior set disablelastaccess 1 >nul 2>&1
fsutil behavior set disable8dot3 1 >nul 2>&1
echo  [OK] Timestamps y 8.3 desactivados.

echo.
echo  [PASO 4] Desactivando suspension del disco...
powercfg -change -disk-timeout-ac 0 >nul 2>&1
powercfg -change -disk-timeout-dc 0 >nul 2>&1
echo  [OK] Disco siempre activo.

echo.
echo  ============================================================
echo   SSD NVMe TURBO FREE - COMPLETADO
echo  ============================================================
echo.
echo   Cambios aplicados en esta version FREE:
echo   [OK] TRIM activado (salud a largo plazo del SSD)
echo   [OK] Timestamps y nombres 8.3 desactivados
echo   [OK] Suspension del disco desactivada
echo.
echo  ============================================================
echo   BLOQUEADO EN PLAN FREE - DISPONIBLE EN NEXO OPTIMIZER PRO:
echo  ============================================================
echo.
echo   [PRO] Native NVMe Stack de Windows 11 24H2
echo         (Hasta 64.000 colas paralelas, +80%% IOPS real)
echo         (Necesario para aprovechar DirectStorage)
echo.
echo   [PRO] SysMain (Superfetch) desactivado
echo         (Libera RAM y reduce escrituras innecesarias en SSD)
echo.
echo   [PRO] LargeSystemCache corregido a 0
echo         (El valor correcto para SSDs NVMe modernos)
echo.
echo   [PRO] IoPageLockLimit optimizado
echo         (Mejora la gestion de memoria del filesystem)
echo.
echo   Consigue todo esto y mucho mas en:
echo   elnexocenter.com/optimizer
echo  ============================================================
echo.
set /p "reboot=Deseas reiniciar? (S/N): "
if /i "%reboot%"=="S" shutdown /r /t 10 /c "Reiniciando SSD Turbo FREE El Nexo..."
exit
