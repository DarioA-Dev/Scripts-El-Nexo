@echo off
chcp 1252 >nul
setlocal enabledelayedexpansion
title EL NEXO v5.0 - AHORRO BATERIA [PLAN: FREE]
color 0B

:: AUTO-ELEVACION
fsutil dirty query %systemdrive% >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs -WorkingDirectory '%~dp0'"
    exit /b
)
cd /d "%~dp0"

cls
color 0B
echo.
echo  ============================================================
echo    ______ _       _   _ _______   ______  
echo   ^|  ____^|^| ^|     ^| \ ^| ^|^|  ___\ \ / / __ \ 
echo   ^| ^|__  ^| ^|     ^|  \^| ^|^| ^|__  \ V / ^|  ^| ^|
echo   ^|  __^| ^| ^|     ^| . ` ^|^|  __^|  ^> ^<^| ^|  ^| ^|
echo   ^| ^|____^| ^|____ ^| ^|\  ^|^| ^|____/ . \ ^|__^| ^|
echo   ^|______^|^|______^|^|_^| \_^|^|______/_/\_\____/  
echo.
echo  ============================================================
echo   AHORRO BATERIA   ^|   PLAN: FREE
echo   Para la version completa: elnexocenter.com/optimizer
echo  ============================================================
echo.

set /p "backup=Crear punto de restauracion? (S/N): "
if /i "%backup%"=="S" (
    powershell -Command "Checkpoint-Computer -Description 'El Nexo Ahorro Bateria FREE' -RestorePointType 'MODIFY_SETTINGS'" 2>nul
    if !errorlevel! equ 0 (echo  [OK] Punto creado.) else (echo  [!] No se pudo crear.)
) else (echo  [!] Saltando respaldo.)
echo.

echo  [PASO 1/3] Creando plan de ahorro inteligente...
set "NEXO_ECO_GUID=33333333-3333-3333-3333-333333333333"
powercfg -delete %NEXO_ECO_GUID% >nul 2>&1
powercfg -duplicatescheme a1841308-3541-4fab-bc81-f71556f20b4a %NEXO_ECO_GUID% >nul 2>&1
powercfg -changename %NEXO_ECO_GUID% "Ahorro Inteligente El Nexo" "Plan El Nexo FREE" >nul 2>&1
powercfg -setactive %NEXO_ECO_GUID%
powercfg -change -monitor-timeout-dc 3 >nul 2>&1
powercfg -change -disk-timeout-dc 5 >nul 2>&1
powercfg -change -standby-timeout-dc 10 >nul 2>&1
powercfg -h on >nul 2>&1
powercfg -setdcvalueindex %NEXO_ECO_GUID% sub_processor PROCTHROTTLEMIN 5 >nul 2>&1
powercfg -setdcvalueindex %NEXO_ECO_GUID% sub_processor PROCTHROTTLEMAX 75 >nul 2>&1
powercfg -setdcvalueindex %NEXO_ECO_GUID% sub_processor PERFBOOSTMODE 0 >nul 2>&1
echo  [OK] Plan ECO activado (CPU al 75%%).

echo.
echo  [PASO 2/3] Reduciendo efectos visuales...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "EnableTransparency" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\DWM" /v "EnableAeroPeek" /t REG_DWORD /d 0 /f >nul 2>&1
echo  [OK] Transparencias desactivadas.

echo.
echo  [PASO 3/3] Limitando apps de segundo plano...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v "GlobalUserDisabled" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsRunInBackground" /t REG_DWORD /d 2 /f >nul 2>&1
echo  [OK] Apps de fondo bloqueadas.

echo.
echo  ============================================================
echo   AHORRO BATERIA FREE - COMPLETADO
echo  ============================================================
echo.
echo   Cambios aplicados en esta version FREE:
echo   [OK] Plan ECO personalizado (CPU al 75%%)
echo   [OK] Efectos visuales reducidos
echo   [OK] Apps de fondo bloqueadas
echo.
echo  ============================================================
echo   BLOQUEADO EN PLAN FREE - DISPONIBLE EN NEXO OPTIMIZER PRO:
echo  ============================================================
echo.
echo   [PRO] Turbo Boost desactivado en bateria
echo         (Reduce consumo hasta un 25%% en carga media)
echo.
echo   [PRO] Brillo adaptativo segun la luz ambiente
echo         (Ahorro real y automatico sin hacer nada)
echo.
echo   [PRO] Power Throttling inteligente de CPU
echo         (Windows gestiona el uso segun la tarea)
echo.
echo   [PRO] Energy-Efficient Ethernet desactivado correctamente
echo         (Sin picos de CPU por la NIC en reposo)
echo.
echo   [PRO] Indexacion de disco desactivada en bateria
echo         (Ahorra IOPS y calor en SSDs lentos)
echo.
echo   Consigue todo esto y mucho mas en:
echo   elnexocenter.com/optimizer
echo  ============================================================
echo.
start powercfg.cpl
pause
exit
