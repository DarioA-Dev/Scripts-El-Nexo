@echo off
setlocal EnableDelayedExpansion
cls
color 0b

echo.
echo  =============================================================
echo    EL NEXO BENCHMARK - v18
echo    Analisis de Hardware y Rendimiento
echo  =============================================================
echo.

:: Verificacion Admin
fsutil dirty query %systemdrive% >nul 2>&1
if %errorlevel% neq 0 goto :ERROR_NO_ADMIN

echo   [!] Analizando tu equipo... Por favor espera.
echo.

set "PS1=%TEMP%\nexo_hwinfo.ps1"
del "%PS1%" >nul 2>&1

>  "%PS1%" echo $ErrorActionPreference = 'Stop'
>> "%PS1%" echo try {
>> "%PS1%" echo   Write-Host '   [+] Leyendo CPU...' -ForegroundColor Cyan
>> "%PS1%" echo   $cpu = (Get-CimInstance Win32_Processor).Name
>> "%PS1%" echo   Write-Host '   [+] Leyendo GPU...' -ForegroundColor Cyan
>> "%PS1%" echo   $gpu = (Get-CimInstance Win32_VideoController ^| Where-Object { $_.Name -notlike '*Basic*' } ^| Select-Object -First 1).Name
>> "%PS1%" echo   if (-not $gpu) { $gpu = (Get-CimInstance Win32_VideoController ^| Select-Object -First 1).Name }
>> "%PS1%" echo   Write-Host '   [+] Leyendo RAM...' -ForegroundColor Cyan
>> "%PS1%" echo   $ramGB = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 1)
>> "%PS1%" echo   Write-Host '   [+] Leyendo Sistema...' -ForegroundColor Cyan
>> "%PS1%" echo   $winVer = (Get-CimInstance Win32_OperatingSystem).Caption
>> "%PS1%" echo   Write-Host '   [+] Leyendo almacenamiento...' -ForegroundColor Cyan
>> "%PS1%" echo   $disk = Get-CimInstance Win32_DiskDrive ^| Select-Object -First 1
>> "%PS1%" echo   $diskModel = $disk.Model
>> "%PS1%" echo   $diskGB = [math]::Round($disk.Size / 1GB, 0)
>> "%PS1%" echo   $ssdCheck = Get-PhysicalDisk ^| Select-Object -First 1
>> "%PS1%" echo   $diskType = $ssdCheck.MediaType
>> "%PS1%" echo   if (-not $diskType -or $diskType -eq 'Unspecified') { $diskType = 'SSD/NVMe' }
>> "%PS1%" echo   Write-Host '   [+] Leyendo apps de inicio...' -ForegroundColor Cyan
>> "%PS1%" echo   $startupApps = Get-CimInstance Win32_StartupCommand ^| Select-Object Name, Command, Location
>> "%PS1%" echo   $startupReg  = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -ErrorAction SilentlyContinue
>> "%PS1%" echo   $startupCount = $startupApps.Count
>> "%PS1%" echo   if ($startupReg) { $startupCount += ($startupReg.PSObject.Properties ^| Where-Object { $_.Name -notlike 'PS*' }).Count }
>> "%PS1%" echo   $nl = [Environment]::NewLine
>> "%PS1%" echo   $desktop   = [Environment]::GetFolderPath('Desktop')
>> "%PS1%" echo   $outFolder = Join-Path $desktop 'Resultados_El_Nexo'
>> "%PS1%" echo   New-Item -ItemType Directory -Force -Path $outFolder ^| Out-Null
>> "%PS1%" echo   $outFile  = Join-Path $outFolder 'resultado_nexo.txt'
>> "%PS1%" echo   $guiaFile = Join-Path $outFolder 'GUIA_MEJORAR_RENDIMIENTO.txt'
>> "%PS1%" echo   $content  = '=== EL NEXO CENTER - BENCHMARK REPORT ===' + $nl
>> "%PS1%" echo   $content += '-----------------------------------------' + $nl
>> "%PS1%" echo   $content += 'VERSION=18' + $nl
>> "%PS1%" echo   $content += 'FUENTE_DATO=WMI_HW_SCAN' + $nl
>> "%PS1%" echo   $content += '-----------------------------------------' + $nl
>> "%PS1%" echo   $content += 'CPU='          + $cpu        + $nl
>> "%PS1%" echo   $content += 'GPU='          + $gpu        + $nl
>> "%PS1%" echo   $content += 'RAM='          + $ramGB      + ' GB' + $nl
>> "%PS1%" echo   $content += 'SISTEMA='      + $winVer     + $nl
>> "%PS1%" echo   $content += 'DISCO='        + $diskModel  + $nl
>> "%PS1%" echo   $content += 'DISCO_GB='     + $diskGB     + ' GB' + $nl
>> "%PS1%" echo   $content += 'DISCO_TIPO='   + $diskType   + $nl
>> "%PS1%" echo   $content += 'APPS_INICIO='  + $startupCount + $nl
>> "%PS1%" echo   $content += '-----------------------------------------' + $nl
>> "%PS1%" echo   $content += 'SUBE ESTE ARCHIVO A: elnexocenter.com'
>> "%PS1%" echo   Set-Content -Path $outFile -Value $content -Encoding UTF8
>> "%PS1%" echo   $guia  = '================================================================' + $nl
>> "%PS1%" echo   $guia += '  GUIA: COMO MEJORAR EL RENDIMIENTO DE TU PC' + $nl
>> "%PS1%" echo   $guia += '  El Nexo Center - Optimizacion de Hardware y Software' + $nl
>> "%PS1%" echo   $guia += '================================================================' + $nl + $nl
>> "%PS1%" echo   $guia += 'TU EQUIPO DETECTADO:' + $nl
>> "%PS1%" echo   $guia += "  CPU    : $cpu" + $nl
>> "%PS1%" echo   $guia += "  GPU    : $gpu" + $nl
>> "%PS1%" echo   $guia += "  RAM    : $ramGB GB" + $nl
>> "%PS1%" echo   $guia += "  DISCO  : $diskModel ($diskGB GB - $diskType)" + $nl
>> "%PS1%" echo   $guia += "  APPS INICIO: $startupCount programas" + $nl + $nl
>> "%PS1%" echo   $guia += '================================================================' + $nl
>> "%PS1%" echo   $guia += '  1. OPTIMIZACION DE SOFTWARE (GRATIS)' + $nl
>> "%PS1%" echo   $guia += '================================================================' + $nl + $nl
>> "%PS1%" echo   $guia += 'APPS DE INICIO - Desactiva las innecesarias:' + $nl
>> "%PS1%" echo   $guia += '  Como hacerlo: Ctrl+Shift+Esc > Inicio > Click derecho > Deshabilitar' + $nl
>> "%PS1%" echo   $guia += '  Candidatos a desactivar:' + $nl
>> "%PS1%" echo   $guia += '    - Discord, Spotify, Steam, Epic Games (abrir manualmente)' + $nl
>> "%PS1%" echo   $guia += '    - OneDrive (si no lo usas a diario)' + $nl
>> "%PS1%" echo   $guia += '    - Microsoft Teams, Skype' + $nl
>> "%PS1%" echo   $guia += '    - Adobe Creative Cloud, Java Updater' + $nl
>> "%PS1%" echo   $guia += '    - Apps de impresoras (HP Smart, Epson, Canon)' + $nl
>> "%PS1%" echo   $guia += '    - NVIDIA GeForce Experience (el driver funciona sin ella)' + $nl + $nl
>> "%PS1%" echo   $guia += 'PLAN DE ENERGIA - Activa Maximo Rendimiento:' + $nl
>> "%PS1%" echo   $guia += '  Panel de control > Hardware > Opciones de energia > Alto rendimiento' + $nl + $nl
>> "%PS1%" echo   $guia += 'ACTUALIZACIONES DE DRIVERS:' + $nl
>> "%PS1%" echo   $guia += '  - GPU: Descarga siempre los drivers mas recientes de NVIDIA/AMD/Intel' + $nl
>> "%PS1%" echo   $guia += '  - Chipset: Descarga los drivers de chipset de la web del fabricante' + $nl + $nl
>> "%PS1%" echo   $guia += 'LIMPIEZA DEL SISTEMA:' + $nl
>> "%PS1%" echo   $guia += '  - Ejecuta "Limpieza_del_sistema_El_Nexo.bat" de la suite Nexo' + $nl
>> "%PS1%" echo   $guia += '  - O manualmente: Win+R > cleanmgr > Limpiar archivos de sistema' + $nl + $nl
>> "%PS1%" echo   $guia += 'MODO DE JUEGO DE WINDOWS:' + $nl
>> "%PS1%" echo   $guia += '  Win+I > Juegos > Modo de juego > Activar' + $nl + $nl
>> "%PS1%" echo   $guia += 'XBOX GAME BAR (desactivar si no la usas):' + $nl
>> "%PS1%" echo   $guia += '  Win+I > Juegos > Xbox Game Bar > Desactivar' + $nl + $nl
>> "%PS1%" echo   $guia += '================================================================' + $nl
>> "%PS1%" echo   $guia += '  2. OPTIMIZACION DE HARDWARE (INVERSION)' + $nl
>> "%PS1%" echo   $guia += '================================================================' + $nl + $nl
>> "%PS1%" echo   $guia += 'RAM - Mejoras recomendadas segun tu capacidad actual:' + $nl
>> "%PS1%" echo   $guia += "  Tienes: $ramGB GB" + $nl
>> "%PS1%" echo   $guia += '  - Con menos de 8 GB : URGENTE ampliar a 16 GB minimo' + $nl
>> "%PS1%" echo   $guia += '  - Con 8 GB           : Ampliar a 16-32 GB mejora mucho en multitarea' + $nl
>> "%PS1%" echo   $guia += '  - Con 16 GB          : Buena base. 32 GB si editas video o usas VMs' + $nl
>> "%PS1%" echo   $guia += '  - Con 32 GB o mas    : Mas que suficiente para la mayoria de usos' + $nl + $nl
>> "%PS1%" echo   $guia += 'ALMACENAMIENTO:' + $nl
>> "%PS1%" echo   $guia += "  Tienes: $diskModel ($diskGB GB - $diskType)" + $nl
>> "%PS1%" echo   $guia += '  - Si tienes HDD: Pasar a SSD NVMe es la mejora mas notoria posible' + $nl
>> "%PS1%" echo   $guia += '  - Si tienes SSD SATA: Un NVMe PCIe 4.0 duplica velocidades' + $nl
>> "%PS1%" echo   $guia += '  - Si tienes NVMe: Ya tienes lo mejor. Prioriza CPU/GPU' + $nl + $nl
>> "%PS1%" echo   $guia += 'GPU - Cuanto mejoras con un upgrade:' + $nl
>> "%PS1%" echo   $guia += '  La GPU es el componente que mas impacta en gaming y creacion de contenido.' + $nl
>> "%PS1%" echo   $guia += '  Consulta el diagnostico de sinergia en elnexocenter.com' + $nl
>> "%PS1%" echo   $guia += '  para saber si tu CPU limita tu GPU o viceversa.' + $nl + $nl
>> "%PS1%" echo   $guia += '================================================================' + $nl
>> "%PS1%" echo   $guia += '  3. AJUSTES EN JUEGOS' + $nl
>> "%PS1%" echo   $guia += '================================================================' + $nl + $nl
>> "%PS1%" echo   $guia += '  - Activa NVIDIA DLSS / AMD FSR / Intel XeSS segun tu GPU' + $nl
>> "%PS1%" echo   $guia += '  - Reduce Sombras y Distancia de dibujado (mayor impacto en FPS)' + $nl
>> "%PS1%" echo   $guia += '  - Usa V-Sync desactivado + framerate cap manual (menos latencia)' + $nl
>> "%PS1%" echo   $guia += '  - Activa Resizable BAR / Smart Access Memory si tu equipo lo soporta' + $nl
>> "%PS1%" echo   $guia += '  - En NVIDIA: Panel de control > Gestion de energia > Maximo rendimiento' + $nl + $nl
>> "%PS1%" echo   $guia += '================================================================' + $nl
>> "%PS1%" echo   $guia += '  Vuelve a ejecutar el benchmark tras optimizar para ver tu mejora' + $nl
>> "%PS1%" echo   $guia += '  y sube tu resultado a elnexocenter.com para obtener tu rango!' + $nl
>> "%PS1%" echo   $guia += '================================================================'
>> "%PS1%" echo   Set-Content -Path $guiaFile -Value $guia -Encoding UTF8
>> "%PS1%" echo   Write-Host ''
>> "%PS1%" echo   Write-Host '  =============================================' -ForegroundColor DarkCyan
>> "%PS1%" echo   Write-Host '        ANALISIS COMPLETADO                    ' -ForegroundColor White
>> "%PS1%" echo   Write-Host '  =============================================' -ForegroundColor DarkCyan
>> "%PS1%" echo   Write-Host "   CPU    : $cpu" -ForegroundColor Yellow
>> "%PS1%" echo   Write-Host "   GPU    : $gpu" -ForegroundColor Yellow
>> "%PS1%" echo   Write-Host "   RAM    : $ramGB GB" -ForegroundColor Yellow
>> "%PS1%" echo   Write-Host "   DISCO  : $diskModel ($diskGB GB - $diskType)" -ForegroundColor Yellow
>> "%PS1%" echo   Write-Host "   INICIO : $startupCount apps" -ForegroundColor Yellow
>> "%PS1%" echo   Write-Host '  =============================================' -ForegroundColor DarkCyan
>> "%PS1%" echo   Write-Host '   RANGO  : ??? (Subelo a elnexocenter.com)' -ForegroundColor Cyan
>> "%PS1%" echo   Write-Host '  =============================================' -ForegroundColor DarkCyan
>> "%PS1%" echo   Write-Host ''
>> "%PS1%" echo   Write-Host '   Informe guardado en el Escritorio.' -ForegroundColor Green
>> "%PS1%" echo   Write-Host '   Abriendo navegador...' -ForegroundColor Green
>> "%PS1%" echo   Start-Sleep -Seconds 2
>> "%PS1%" echo   $url    = 'https://elnexocenter.com/nexos/benchmark.html'
>> "%PS1%" echo   $chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe","$env:ProgramFiles(x86)\Google\Chrome\Application\chrome.exe","$env:LocalAppData\Google\Chrome\Application\chrome.exe") ^| Where-Object { Test-Path $_ } ^| Select-Object -First 1
>> "%PS1%" echo   $edge   = @("$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe","$env:ProgramFiles(x86)\Microsoft\Edge\Application\msedge.exe") ^| Where-Object { Test-Path $_ } ^| Select-Object -First 1
>> "%PS1%" echo   if ($chrome) { Start-Process $chrome $url } elseif ($edge) { Start-Process $edge $url } else { Start-Process $url }
>> "%PS1%" echo   Start-Process explorer.exe $outFolder
>> "%PS1%" echo } catch {
>> "%PS1%" echo   Write-Host ''
>> "%PS1%" echo   Write-Host "   [ERROR]: $($_.Exception.Message)" -ForegroundColor Red
>> "%PS1%" echo   Write-Host "   Linea  : $($_.InvocationInfo.ScriptLineNumber)" -ForegroundColor Red
>> "%PS1%" echo   Read-Host '   Pulsa Enter para cerrar'
>> "%PS1%" echo }

powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
del "%PS1%" >nul 2>&1

echo.
echo  [FIN] Pulsa cualquier tecla para cerrar.
pause >nul
exit

:ERROR_NO_ADMIN
cls
color 0c
echo.
echo  =============================================================
echo    ERROR: SIN PERMISOS DE ADMINISTRADOR
echo  =============================================================
echo.
echo   Click derecho sobre el archivo y selecciona:
echo   "Ejecutar como administrador"
echo.
pause
exit
