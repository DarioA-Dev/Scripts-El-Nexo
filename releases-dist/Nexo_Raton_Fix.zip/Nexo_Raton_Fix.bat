@echo off
chcp 1252 >nul
setlocal enabledelayedexpansion
title EL NEXO v5.0 - RATON FIX [PLAN: FREE]
color 0B

fsutil dirty query %systemdrive% >nul 2>&1
if %errorlevel% neq 0 (
    cls & color 0C
    echo.
    echo  ============================================================
    echo   ACCESO DENEGADO - Se requieren permisos de Administrador
    echo  ============================================================
    echo   Haz clic derecho y selecciona "Ejecutar como administrador"
    echo  ============================================================
    pause & exit /b
)

cls
color 0B
echo.
echo  ============================================================
echo    ______ _       _   _ _______   ______  
echo   ^|  ____^|^| ^|     ^| \ ^| ^|^|  ___\ \ / / __ \ 
echo   ^| ^|__  ^| ^|     ^|  \^| ^|^| ^|__  \ V / ^|  ^| ^|
echo   ^|  __^| ^| ^|     ^| . ` ^|^|  __^|  ^> ^<^| ^|  ^| ^|
echo   ^| ^|____^| ^|____ ^| ^|\  ^|^| ^|____/ . \ ^|__^| ^|
echo   ^|______^|^|______^|^|_^| \_^|^|______/_/\_\____/  
echo.
echo  ============================================================
echo   RATON FIX   ^|   PLAN: FREE
echo   Para la version completa: elnexocenter.com/optimizer
echo  ============================================================
echo.

echo  [PASO 1] Creando punto de restauracion...
powershell -Command "Checkpoint-Computer -Description 'El Nexo Raton Fix FREE' -RestorePointType 'MODIFY_SETTINGS'" 2>nul
echo  [OK] Punto creado.

echo.
echo  [PASO 2] Desactivando aceleracion del puntero...
reg add "HKCU\Control Panel\Mouse" /v "MouseSpeed" /t REG_SZ /d "0" /f >nul 2>&1
reg add "HKCU\Control Panel\Mouse" /v "MouseThreshold1" /t REG_SZ /d "0" /f >nul 2>&1
reg add "HKCU\Control Panel\Mouse" /v "MouseThreshold2" /t REG_SZ /d "0" /f >nul 2>&1
echo  [OK] Aceleracion basica desactivada.

echo.
echo  [PASO 3] Reduciendo latencia de menus...
reg add "HKCU\Control Panel\Desktop" /v "MenuShowDelay" /t REG_SZ /d "0" /f >nul 2>&1
echo  [OK] MenuShowDelay a 0ms.

echo.
echo  ============================================================
echo   RATON FIX FREE - COMPLETADO
echo  ============================================================
echo.
echo   Cambios aplicados en esta version FREE:
echo   [OK] Aceleracion basica de puntero desactivada
echo   [OK] MenuShowDelay reducido a 0ms
echo.
echo  ============================================================
echo   BLOQUEADO EN PLAN FREE - DISPONIBLE EN NEXO OPTIMIZER PRO:
echo  ============================================================
echo.
echo   [PRO] UserPreferencesMask corregido
echo         Desactiva "Enhance Pointer Precision" a nivel de sistema
echo         La version FREE NO desactiva esto completamente
echo         (El Panel de Control puede volver a activarlo)
echo.
echo   [PRO] SmoothMouseXCurve y SmoothMouseYCurve linealizadas
echo         Elimina la curva de aceleracion a nivel de driver
echo         Sin esto la precision 1:1 real no esta garantizada
echo.
echo   [PRO] MouseDataQueueSize optimizado
echo         Mejora la estabilidad del buffer del controlador
echo.
echo   Consigue todo esto y mucho mas en:
echo   elnexocenter.com/optimizer
echo  ============================================================
echo.
set /p "reboot=Deseas reiniciar? (S/N): "
if /i "%reboot%"=="S" shutdown /r /t 10 /c "Reiniciando Raton Fix FREE El Nexo..."
exit
